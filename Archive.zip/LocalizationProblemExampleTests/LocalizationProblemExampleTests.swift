//
//  LocalizationProblemExampleTests.swift
//  LocalizationProblemExampleTests
//
//  Created by Michel Storms on 25/07/2024.
//

import Testing
@testable import LocalizationProblemExample

struct LocalizationProblemExampleTests {

    @Test func testExample() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
